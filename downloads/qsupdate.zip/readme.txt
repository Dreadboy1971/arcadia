Extract all files to your QuickMAME/QuickMESS directory.

(i.e. C:\QMLAUNCH)